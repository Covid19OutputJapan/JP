function plot_N_baseline_diff(TH,TH_index,N,NPath,alpha,AlphaPath,ERN,SimERN,MonthWeekEN,MonthWeekJP,WeekNumber,Tdata,linecolor,fs,fs_legend,fn,ft,l,WeekOlympic)
%plot Simulated New Cases
ymax = max(NPath(2:end,1:size(TH,1)-1)/7 -NPath(2:end,size(TH,1))/7,[],'all')*1.15;
fill([Tdata+WeekOlympic+2 Tdata+WeekOlympic+4 Tdata+WeekOlympic+4 Tdata+WeekOlympic+2], [00 00 ymax ymax],0.95*[1 1 1]);
hold on
fill([Tdata+WeekOlympic+7 Tdata+WeekOlympic+8 Tdata+WeekOlympic+8 Tdata+WeekOlympic+7], [00 00 ymax ymax],0.95*[1 1 1]);
th_wave = 1;
for i = 1:length(TH)-1
    if  sum(TH(i,:) == TH_index(th_wave,:)) == size(TH,2)
        mainplot(i) = plot(([N;NPath(:,i)]-[N;NPath(:,size(TH,1))])/7,linecolor{th_wave},'LineWidth',2);
        hold on
        th_wave = th_wave + 1;
        if th_wave > length(TH_index)
            th_wave = length(TH_index);
        end
    else
        plot(([N;NPath(:,i)]-[N;NPath(:,size(TH,1))])/7,'--','LineWidth',0.3)
    end
    hold on
end
%plot(N/7,'k','LineWidth',2,'HandleVisibility','off')
%xline(Tdata,'LineWidth',1.5,'HandleVisibility','off');
%xline(Tdata+WeekOlympic,'LineWidth',1.5,'HandleVisibility','off');
ylim([0 ymax]);

ax = gca;
ax.YAxis.FontSize = fs;
ax.XAxis.FontSize = fs;
ax.YAxis.Exponent = 0;
ytickformat('%,6.0f')
xticks(find(WeekNumber==1))
if l == 1
    title('Projected path of new cases','FontSize',fs,'FontWeight','normal')
    xticklabels(MonthWeekEN(WeekNumber==1))
    %xticklabels(datestr(MonthWeekEN(xtick1), 'mmm-yy'))
    legend([mainplot(1),mainplot(2)], 'Baseline','Optimistic','FontSize',fs_legend,'Location','southeast');
elseif l == 2
    title('新規感染者数の差分','FontSize',fs,'FontWeight','normal','FontName',fn)
    xticklabels(MonthWeekJP(WeekNumber==1))
    legend([mainplot(2),mainplot(4)], '経済活動0.5pp追加上昇','経済活動0pp追加上昇','FontSize',fs_legend,'FontName',fn,'Location','northwest');
end

xtickangle(45)
xlim([Tdata+WeekOlympic-4 Tdata+33])

