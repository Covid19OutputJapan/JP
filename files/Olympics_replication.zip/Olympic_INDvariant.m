% This m-file executes simulation and generates figures for the
% analysis of the state of emergency placed in Tokyo in the paper
% "Covid-19 and Output in Japan" by Daisuke Fujii and Taisuke
% Nakata

%インド型変異株シナリオ

clear variables
close all
iPC=1; % 0 for Mac, 1 for Windows
if iPC==1
    %home =
else
    %home =
end
cd(home);
%====================== Program parameter values ======================%
figure_save = 0;    % 0 = figures won't be saved, 1 = they will be saved
data_save = 0;      % save back data
vaccine_figure_loop = 0; % =0 appear only once; =1 appear every loop; 
beta_figure_loop = 0; % =0 appear only once; =1 appear every loop; 
vaccine_disp_switch = 0; % =0 not display the summry of # of the vaccinated ; =1 display 
% in the "Figure" folder
fs = 16;            % common font size for many figures
ldfs = 8;           % legend font size for vaccine path
if iPC == 1
    fn = 'Yu Gothic';     % Font style for xaxis, yaxis, title
else
    fn = 'YuGothic';
end
linecolor = {'red','blue','black','green'};
language = {'EN','JP'};
%======================================================================%

%================== Model Fixed Parameter Values ============================%
SimPeriod = 52;        % simulation period in weeks
gamma = 7/12;          % recovery rate from Covid % Should change this to 7/12 (4/25 Kohei Machi)
k = 2;                 % exponent of (1-h*alpha)
hconstant = 1;         % 0 = without intercept, 1 = with intercept for h regression
medical_start_date = datetime(2021,3,18);
elderly_start_date = datetime(2021,5,13);
RetroPeriod = 17;      % retroactive periods used to estimate gamma and delta
tt = 12; % Showing previous t periods for the plot
% Parameters for beta
beta_rho = 0.5;
retro_ub = 17; % Control the moving average of beta (beta_avg = sum_{t = lb}^{ub} (1/(ub-lb + 1) sum_{x=1}^t (1/t) beta_t)
retro_lb = 17;
% Parameters for mobility estimation
retroH_switch = 1; %If retroH_switch == 1, retroH = TdataGDP - 4, else = retroH
RetroH = 15;
% Parameters for variants
%var_infection = 0.4;
var_infection = 0.3;
var_ss = 1.0;         % steady-state share of variant
var_growth = 0.47;

% Parameters for Vaccine Path
VacPlan = 1;
%VacPlan = 2;
if VacPlan == 1
   paces_ori = 4200000;
   gradual_paces = 4;
elseif VacPlan == 2
   paces_ori = 7000000;
   gradual_paces = 4;
end
sw_vacpath = 0;
% Population
POP_jp = 125710000;
medical_jp = 4700000;
elderly_jp = 36000000;
ordinary_jp = (POP_jp-elderly_jp-medical_jp);
accept_share = 0.8;
% vaccine type
PF = 1; % 0 for AZ, 1 for PF
if PF == 0  % AZ
    E1 = 0.615;
    E2 = 0.64;
    D1 = 0.8;
    D2 = 0.85;
else   % PF
    E1 = 0.625;
    E2 = 0.895;
    D1 = 0.8;
    D2 = 0.94;
end

%Athlete vaccination 
Ratio_AZ = 0.5;
Ratio_PF = 0.5;
EffectiveE2 = Ratio_AZ*0.64 + Ratio_PF*0.895;
% ICU paraemters
gamma_ICU = 7/28;
ICU_inflow_adjustment = 0.8;


%================== Parameter Values (Prefecture Specific) ============================%
PrefVector = {'Tokyo','Kanagawa','Saitama','Chiba','Osaka','Aichi','Fukuoka','Hyogo'};
GDPVector = [106,36,23,21,40,41,20,20]; % 兆円, one trillion yen (chou-yen)
ICU_limit_vector = [373,0,0,0,659];
% 緊急事態宣言の発令基準
th_on_vector = [1000,500,400,350,1200,350,350]; % present.
%th_on_vector2 = [2000,1000,800,700,2000,350,350]; % 高齢者がうち終わったあとの基準
th_on_vector2 = [2250,1000,800,700,2000,350,350];
%th_on_vector2 = [3000,1000,800,700,2000,350,350];
% 緊急事態宣言の解除基準
th_off_vector = [450,100,110,80,800,50,60]; %1回目の緊急事態宣言の解除基準
%th_off_vector = [600,100,110,80,800,50,60]; %1回目の緊急事態宣言の解除基準
th_off_vector2 = [450,100,80,60,800,50,60]; %2回目の緊急事態宣言の解除基準
th_off_vector3 = [450,100,80,60,800,50,60]; %3回目の緊急事態宣言の解除基準
% 経済回復速度
%DRi_vector = [6,6,6,6,6,6,6,6];
DRi_vector = [10,10,10,10,10,10,10,10];
% 緊急事態宣言の強さの基準: Simulation開始時のERNをいくつにするか
%ERN_on_vector =  [0.55,0.5,0.5,0.5,0.65]; % 緊急事態宣言下のERN
alpha_on_vector = [0.2,0.1,0.1,0.1,0.2];
% Size of AR(1) shock for beta process
betaT_temp_ini_vec = [-0.05,0,0,0,0.2,0,0,0];%0.15
start_beta_vec = [2,1,1,1,1];
beta_rho_vec = [0.5,0,0,0,0.75];
% Initial Share of Variants (Need to change these values every week)
%var_initial_vector = [0.2531, 0.2909, 0.1335, 0.0909, 0.7721, 0, 0, 0,0]; % 4/26
% var_initial_vector = [0.4035, 0.3280, 0.3261, 0.3008, 0.8224, 0, 0, 0,0]; % 5/3 (4/11-4/18のデータ)
%var_initial_vector = [0.556244, 0.450617, 0.514451, 0.422360, 0.824487, 0, 0, 0,0]; % 5/10 (4/19-4/25のデータ)
var_initial_vector = [0.631038, 0.596774, 0.578947, 0.56,     0.856401, 0, 0, 0, 0];% 5/17 (4/26-5/2のデータ)
%var_ss_vector = [1, 1, 1, 1, 0.85, 0, 0, 0,0]; % 5/10
var_ss_vector = [1, 1, 1, 1, 0.9, 0, 0, 0,0]; % 5/17
share_index = 2; % = 2 for Monday, = 1 after Wednesday
%=========== use this code to extrapolate var_initial_vector ==================%
var_initial_vector = ini2now_infection_rate(var_initial_vector,var_growth,var_ss_vector,SimPeriod,share_index);
%=====================================================%


for pindex = 1:1 %:length(PrefVector) %change this parameter for prefecture
    %====================== Model parameter values ======================%
    pref = PrefVector{pindex};        % prefecture to be analyzed
    prefGDP = GDPVector(pindex);
    %====================================================================%
  
    ICU_limit = ICU_limit_vector(pindex);
    betaT_temp_ini = betaT_temp_ini_vec(pindex);
    start_beta = start_beta_vec(pindex);
    beta_rho = beta_rho_vec(pindex);
    var_initial = var_initial_vector(pindex);
    var_ss = var_ss_vector(pindex);
    %--- Import data ---%
    % Covid data are recorded at weekly frequencies (Mon-Sun)
    % The first week start on January 20 (Mon), 2020
    import_prefecture
    
     %--- Construct weekly vaccine data ---%　
    [V1_medical_ori, V1_medical, V2_medical_ori, V2_medical,...
        V1_elderly_ori, V1_elderly, V2_elderly_ori, V2_elderly, ...
        vs_MT,vs_ET,vs_M1,vs_E1,vs_M2,vs_E2] ...
        = ImportVaccineData(home,iPC,pref,dateEN,ps,vaccine_disp_switch);
      
     %--- Constructing the reference level of output ---%
    [potentialGDP, referenceGDP, alpha] = construct_GDP(GDP,TdataGDP);
    
    %--- Regress mobility on alpha to estimate the elasticity h ---%　関数化？
    [Malt,h_all,h_all_se,h,h_se] = estimate_h(M,alpha,TdataGDP,RetroH,hconstant);

    %--- Import ICU data (Option 2) ---%
    if iPC==1
        ICUdata2 = importdata([home 'ICUdeath_pref.csv']);  % Import weekly Covid data by prefecture
    else
        ICUdata2 = importdata([home 'ICUdeath_pref.csv']);  % Import weekly Covid data by prefecture
    end
    ICUdata2_pref = ICUdata2.data(strcmp(ICUdata2.textdata(2:end,1),pref),:); %same length as covid_weekly.csv
    if pindex == 1
        ICUdata2_pref = [nan(4,4); ICUdata2_pref];
    elseif pindex == 5
        ICUdata2_pref = [nan(8,4); ICUdata2_pref];
    end
    dateICU  = ICUdata2_pref(:,1) + 21916;
    dateICU_EN = datetime(dateICU,'ConvertFrom','excel');
    ICU = ICUdata2_pref(:,2);

    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%% Main analysis starts here %%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Projection parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    DRi = DRi_vector(pindex);
    th_on1 = th_on_vector(pindex)*7;         % threshold to place the state of emergency
    th_on2 = th_on_vector2(pindex)*7;         % threshold to place the state of emergency
    th_off1 = th_off_vector(pindex)*7;
    th_off2 = th_off_vector2(pindex)*7;
    th_off3 = th_off_vector3(pindex)*7;
    alpha_on = alpha_on_vector(pindex); %(((ERN_on*(POP0/S(end))*((gammaT(1)+delta_average)/beta_avg)).^(1/k))-1)*(h(1)/h(2));
    
    
    FlowAthlete = 70000; %オリンピック関係７万人 
    FlowAthleteP = 35000; %パラリンピック3.5万人
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%% CHANGE HERE %%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %3 cases (1) No Olympic (2) Olympic w/ alpha=0.5pp, I0=100 without Indian variant
    %(3)Olympic w/ alpha=0.5pp, I0=100 with Indian variant
    
    %2 indicators: 1st one - Olympic, 2nd one - Indian variant
    TH = [1,1;1,0;0,0]; 
    TH_index = TH;
    if pindex == 1 || pindex == 5
        state = 1;
    else 
        state = 0;
    end 
    alpha_May = mean(alpha((dateEN >= datetime(2020,5,07)) & (datetime(2020,5,28)>= dateEN ))); 
    alpha_Jan = mean(alpha((dateEN >= datetime(2021,1,07)) & (datetime(2021,1,28)>= dateEN ))); 
    if pindex == 1
        alpha_on = 0.5*alpha_May+0.5*alpha_Jan;
    elseif pindex == 5
        alpha_on = 1.25*alpha_May;
    end 


    if max(TH)<3
        ft = '%.2f';
    else
        ft = '%.0f';
    end

    
    
    %Number of weeks to Olympic Opening from the current date    
     WeekOlympicOpen = hours(datetime(2021,7,8)-dateEN(end))/24/7; %Week starting from July 5th
     WeekOlympicClose = hours(datetime(2021,8,12)-dateEN(end))/24/7; %Week starting from August 9
     WeekParalympicOpen = hours(datetime(2021,8,12)-dateEN(end))/24/7; %Week starting from Aug 9 
     WeekParalympicClose = hours(datetime(2021,9,9)-dateEN(end))/24/7; %2nd week of September
 

    DMat = nan(1,length(TH));
    AlphaMat = nan(1,length(TH));
    SimData = nan(SimPeriod+1,4,length(TH));
    ICUMat = nan(SimPeriod+1,length(TH));
    AlphaPath = nan(SimPeriod,length(TH));
    NPath = nan(SimPeriod,length(TH));
    SimERN = nan(SimPeriod,length(TH));
    THonPath = nan(SimPeriod,length(TH));
    BackDataN = zeros(SimPeriod+8,length(TH_index));
    BackDataAlpha = zeros(SimPeriod+8,length(TH_index));
    BackDataERN = zeros(SimPeriod+8,length(TH_index));
    BackDataICU = zeros(SimPeriod+8,length(TH_index));
    BackDataDA = zeros(length(TH),size(TH,2)+2);

    for iTH = 1:length(TH)
        %%%%%%%%%%% Change here %%%%%%%%%%%%%%%%%%%
        OlymPara_Indicator = TH(iTH,1);
        variant_India = TH(iTH,2);
        %%%%%%%%%%%%%%%%%%%%%%%
        %%% Olympic parameter
        %%%%%%%%%%%%%%%%%%%%%%%
        OlympicAlpha = 0.005;
        FlowI = 100;
        VacRate = 0.5;
        
        IAthlete = (7.5/10.5)*FlowI; 
        SAthlete = FlowAthlete - IAthlete;
        EffcFlowS = SAthlete*(1-VacRate) + SAthlete*VacRate*(1-EffectiveE2); %either fully vaccinated or no vaccination
        ExgShockOlym = [EffcFlowS,IAthlete];
        IAthleteP = (3.5/10.5)*FlowI;
        SAthleteP = FlowAthleteP - IAthleteP;
        EffcFlowS = SAthleteP*(1-VacRate) + SAthleteP*VacRate*(1-EffectiveE2);
        ExgShockPara = [EffcFlowS,IAthleteP];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %--- Compute the history of S, I, R, D in the data period ---%
        S = zeros(Tdata+1,1);
        I = zeros(Tdata+1,1);
        R = zeros(Tdata+1,1);
        D = zeros(Tdata+1,1);
        S(1)=POP0;
        for i = 1:Tdata
            S(i+1)=S(i)-N(i)-E1*(V1_elderly(i)+V1_medical(i))-(E2-E1)*(V2_elderly(i)+V2_medical(i));
            I(i+1)=I(i)+N(i)-gamma*I(i)-dD(i);
            R(i+1)=R(i)+gamma*I(i)+E1*(V1_elderly(i)+V1_medical(i))+(E2-E1)*(V2_elderly(i)+V2_medical(i));
            D(i+1)=D(i)+dD(i);
            if i > TdataGDP
                GDP(i) = referenceGDP(i)*(1-alpha(i));
            end
        end
       
        %--- Compute the history of time-varying parameters ---%
        delta = (D(2:Tdata+1)-D(1:Tdata))./I(1:Tdata);                              % death rate
        beta_tilde = (POP0.*N(1:Tdata))./((S(1:Tdata).*I(1:Tdata)));   % overall infection rate
        ERN = (S(1:end-1)/POP0).*beta_tilde./(gamma+delta);                                        % effective reproduction number
         
        ICU_inflow = (ICU(2:Tdata) - ICU(1:Tdata-1) + gamma_ICU.*ICU(1:Tdata-1) + dD(1:Tdata-1))./(delta(1:Tdata-1).*N(1:Tdata-1));
        ICU_inflow_average = mean(ICU_inflow(end-26:end))*ICU_inflow_adjustment;
        if hconstant == 0
            beta = beta_tilde./(1+h_all*alpha).^k;                                      % raw infection rate
        elseif hconstant == 1
            %     beta = beta_tilde./(h(1)+h(2)*alpha).^k;
            beta = beta_tilde./(1+(h_all(2)/h_all(1))*alpha).^k;
        end
        
        %--- Construct time series of parameters ---%
        gammaT = gamma*ones(SimPeriod,1);
        delta_sample = delta(end-RetroPeriod+1:end);
        delta_average = sum(delta_sample.*(I(end-RetroPeriod+1:end)/sum(I(end-RetroPeriod+1:end))));
        
        
        
        %--- Construct vaccine dstribution ---%
        paces = ps*paces_ori; 
        vacpath = zeros(SimPeriod,1);
        vacpath(1+sw_vacpath:gradual_paces) = (paces/(gradual_paces-sw_vacpath)):(paces/(gradual_paces-sw_vacpath)):paces;
        vacpath(gradual_paces+1:end) = paces*ones(SimPeriod-gradual_paces,1);
        elderly_total = ps*elderly_jp;
        medical_total = ps*medical_jp;
        ordinary_total = ps*ordinary_jp;
        medical = medical_total*0.8;
        elderly = elderly_total*0.8;
        ordinary = ordinary_total*accept_share;
        
        elderly = elderly - (sum(V1_elderly));
        [V,deltaT,VT] = vaccine_distribution_medical(vacpath,medical,V1_medical,V2_medical,elderly,V1_elderly,V2_elderly, ordinary,elderly_total,delta_average,E1,E2,D1,D2,ps,POP0,3,10);
        
        %%%% Adjust delta
        var_infection_delta = 0.75;
        deltaT= construct_delta_variant(home,SimPeriod,RetroPeriod,Tdata,dateEN,pref,...
    retro_lb,retro_ub,deltaT,delta,delta_average,var_initial,var_ss,var_infection_delta,var_growth,I);        
             
        
        %% figure for vaccine path 
        if vaccine_figure_loop == 0
            if iTH == 1
%                 plot_vaccinepath(200,VT,V1_w,V2_w,SimPeriod,ps,MonthWeekJP,WeekNumber,Tdata,fs,fn);
                plot_vaccinepath(200,VT,V1_medical,V2_medical,V1_elderly,V2_elderly,SimPeriod,ps,MonthWeekJP,WeekNumber,Tdata,fs,ldfs,fn);
                
                plot_deltapath(201,delta,deltaT,deltaT(1),MonthWeekJP,WeekNumber,Tdata,fs,fn);
                
            end
        elseif vaccine_figure_loop == 1
            title_vec = ["基本見通し", "希望見通し"];
            plot_vaccinepath(200+iTH,VT,V1_medical,V2_medical,V1_elderly,V2_elderly,SimPeriod,ps,MonthWeekJP,WeekNumber,Tdata,fs,ldfs,fn);
            subplot(1,2,1)
           title(string(['新規ワクチン接種本数（週ごと）（',sprintf(ft,TH(iTH)),'）']), 'FontSize',fs,'FontName',fn);
            subplot(1,2,2)
            title(string(['累計ワクチン接種本数（週ごと）（',sprintf(ft,TH(iTH)),'）']), 'FontSize',fs,'FontName',fn);

            plot_deltapath(240+iTH,delta,deltaT,deltaT(1),MonthWeekJP,WeekNumber,Tdata,fs,fn);
            title(string(['致死率（現在のレベルで標準化）（',sprintf(ft,TH(iTH)),'）']), 'FontSize',fs,'FontName',fn);
        end
        
        if figure_save == 1
            saveas(figure(200+iTH), [home 'Figures/'  'Vaccine_path_' num2str(paces_ori) '.png']);
        end
        

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Construct Beta %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        beta_r = 0;
        for retrop = retro_lb:retro_ub
            beta_r = beta_r + mean(beta(end-retrop+1:end));
        end
        beta_avg = beta_r/(retro_ub-retro_lb+1);
%         if pindex == 1
%             beta_avg = beta_avg + 0.05;
%         end
        [betaT,betaT_woAR1,var_share,var_share_prev] = construct_beta(home,SimPeriod,Tdata,dateEN,pref,...
            retro_lb,retro_ub,beta,beta_avg,var_initial,var_ss,var_infection,var_growth);
        [betaT] = beta_AR1(betaT_temp_ini, beta_rho, betaT, start_beta);
        
        %%%%　　　インド株　　　%%%%%
        if variant_India == 1
        var_initial2 = 0.5/100;     % initial variant share
        var_growth2 = 0.5;     % weekly growth parameter for logit model
        var_intercept2 = log(var_initial2/(1-var_initial2));
        var_share2 = exp((1:SimPeriod)'*var_growth2+var_intercept2)./(1+exp((1:SimPeriod)'*var_growth2+var_intercept2));
        var_power = 1+var_share2*var_growth2;
        var_boost = ones(SimPeriod,1);
        var_boost(8+2:end) = var_power(1:SimPeriod-8-1);
        betaT = betaT.*var_boost;
        end
        
        
        alpha_off = mean(alpha((dateEN >= datetime(2020,2,7)) & (datetime(2020,2,28)>= dateEN ))); % output loss without the state of emergency
         InitialValues = [S(end),I(end),R(end),D(end),ICU(end)];         
     
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Simulation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        ExgS = zeros(SimPeriod,1);
        ExgI = zeros(SimPeriod,1);
        if OlymPara_Indicator==1
            ExgS(WeekOlympicOpen) = ExgShockOlym(1);
            ExgS(WeekOlympicClose+1) = -(ExgShockOlym(1) - IAthlete);
            ExgS(WeekParalympicOpen) =  ExgS(WeekParalympicOpen) + ExgShockPara(1);
            ExgS(WeekParalympicClose+1) = -(ExgShockPara(1)-IAthleteP);
            
            ExgI(WeekOlympicOpen) = ExgShockOlym(2);
            ExgI(WeekOlympicClose+1) = - IAthlete;
            ExgI(WeekParalympicOpen) = ExgShockPara(2);
            ExgI(WeekParalympicClose+1) = -IAthleteP;
        end

       
        [DMat(iTH),AlphaMat(iTH),AlphaPath(:,iTH),SimData(:,:,iTH),NPath(:,iTH),SimERN(:,iTH),ICUMat(:,iTH)] ...
                = Covid_projection_ICU_ExgShock...
                (InitialValues,alpha_on,alpha_off,th_on1,th_on2,th_off1,th_off2,th_off3,betaT,gammaT,deltaT,V,h,k,POP0,hconstant,DRi,alpha(end),state,ICU_inflow_average,gamma_ICU,ExgS,ExgI,OlympicAlpha);
             

        
    end
    minAlpha = alpha_off; % 経済損失0 = 2020年10-11月のGDP level
    
    
    AlphaM = AlphaMat(~isnan(AlphaMat));
    AlphaM = (AlphaM - minAlpha)*prefGDP*10000;
    DM = DMat(~isnan(DMat));
    BackDataDA(1:length(TH),:) = [round(AlphaM'),round(DM'),TH(:,1),TH(:,2)];
    %--- Record how many times on and off are triggered ---%
    waves = zeros(1,length(TH));
    for i = 1:length(TH)
        svec = zeros(SimPeriod-1,1);
        for t = 1:SimPeriod-1
            svec(t) = AlphaPath(t+1,i)-AlphaPath(t,i);
        end
        waves(i) = sum(svec>0);
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% Plot 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    for l = 2:2 %1:2 when english version needed; 2:2 only for Japanese
        
        lng = language{l};
        
        
        
       %fs = 12;
        
        Index1 = 1:length(TH);
        Index11= 1:size(TH_index,1);
        figname = string(['Olympic' char(lng)]);
        f = figure('Name',figname);
        set(gcf,'Position',[100,100,1200,500])
        subplot(1,2,1)
        [BackDataN,BackDataAlpha,BackDataERN]= plot_N_INDv(TH,TH_index,N,NPath,alpha,AlphaPath,ERN,SimERN,MonthWeekEN,MonthWeekJP,WeekNumber,Tdata,linecolor,fs,fs,fn,ft,l,WeekOlympicOpen);
        subplot(1,2,2)                                                                                               
        BackDataICU = plot_ICU_INDv(TH,TH_index,ICU,ICUMat,ICU_limit,MonthWeekEN,MonthWeekJP,WeekNumber,Tdata,linecolor,fs,fn,ft,l,th_off1,th_off2,th_off3,WeekOlympicOpen);
        if figure_save == 1
            saveas(f,[home 'Figures/Olympic_INDvariant_level' char(lng) '.png']);
        end
        
    end %End of language loop = figure loop
    
    if data_save == 1
        titleN = strings(1,1+length(TH_index)*3);
        titleN(1) = "週";
        for ti = 1:length(TH_index)
            titleN(1,1+ti) = string(['新規感染者数（',sprintf('%.0f',TH_index(ti)),'）']);
            titleN(1,1+length(TH_index)+ti) = string(['経済活動（',sprintf('%.0f',TH_index(ti)),'）']);
            titleN(1,1+length(TH_index)*2+ti) = string(['実効再生産数（',sprintf('%.0f',TH_index(ti)),'）']);
        end
        TN = table([titleN;MonthWeekJP(Tdata-7:end-1),round(BackDataN(:,1:length(TH_index))/7),round(100*(1-BackDataAlpha(:,1:length(TH_index))),1),round(BackDataERN(:,1:length(TH_index)),2)]);
        titleAD = ["経済損失（億円）","死亡者数","ケース"];
        TAD = table([titleAD;BackDataDA(1:length(TH),:)]);
        
        writetable(TN,[home 'Figures/' char(pref) '/BackData_Vaccine_' char(pref)  '.xls'],'Sheet','新規感染者数（1日平均）','WriteVariableNames',false);
        writetable(TAD,[home 'Figures/' char(pref) '/BackData_Vaccine_' char(pref) '.xls'],'Sheet','経済損失と死亡者数','WriteVariableNames',false);
    end
end %end of prefecture loop


