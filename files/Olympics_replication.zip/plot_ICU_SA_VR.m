function BackDataICU = ...
    plot_ICU_SA_VR(TH,TH_index,ICU,SimICU,ICU_limit,MonthWeekEN,MonthWeekJP,WeekNumber,Tdata,linecolor,fs,fn,ft,l,th_off1,th_off2,th_off3,WeekOlympic)
ymax = max(SimICU,[],'all')*1.05;
ymin = min(SimICU,[],'all')/1.05;
fill([Tdata+WeekOlympic+2 Tdata+WeekOlympic+4 Tdata+WeekOlympic+4 Tdata+WeekOlympic+2], [ymin ymin ymax ymax],0.95*[1 1 1]);
hold on
fill([Tdata+WeekOlympic+7 Tdata+WeekOlympic+8 Tdata+WeekOlympic+8 Tdata+WeekOlympic+7], [ymin ymin ymax ymax],0.95*[1 1 1]);

th_wave = 1;
for i = 1:size(TH,1)
    if sum(TH(i,:) == TH_index(th_wave,:)) == size(TH,2)        
        p(i) = plot([ICU;SimICU(2:end,i)],linecolor{th_wave},'LineWidth',2,'DisplayName',sprintf(ft,TH(i)));
        %p.LineStyle = ':';
%         hold on 
%         yline(TH(i),linecolor{th_wave},TH(i))

        BackDataICU(:,th_wave) = [ICU(end-7:end);SimICU(2:end,i)];
        th_wave = th_wave + 1;
        if th_wave > length(TH_index)
            th_wave = length(TH_index);
        end
    else
        plot([ICU;SimICU(2:end,i)], '--','LineWidth',0.3)
        hold on
        colororder('default')
%         yline(TH(i),'-',TH(i))
%         colororder('default')
    end
    hold on
end

xline(Tdata,'LineWidth',1.5,'HandleVisibility','off');
ylim([[ymin ymax]])

%xline(Tdata+WeekOlympic,'LineWidth',1.5,'HandleVisibility','off');

%yline(ICU_limit,'-g',num2str(ICU_limit),'LineWidth',2.5,'HandleVisibility','off','LabelHorizontalAlignment','left','LabelVerticalAlignment','bottom');

%yline(ICU_limit/2,'-k',num2str(ICU_limit/2),'LineWidth',2.5,'HandleVisibility','off','LabelHorizontalAlignment','left','LabelVerticalAlignment','bottom');

%yline(th_off1,'-r',num2str(th_off1),'LineWidth',1.5,'HandleVisibility','off','LabelHorizontalAlignment','left','LabelVerticalAlignment','bottom');
% yline(th_off2,'-b',num2str(th_off2),'LineWidth',1.5,'HandleVisibility','off','LabelHorizontalAlignment','left','LabelVerticalAlignment','bottom');
% yline(th_off3,'-k',num2str(th_off3),'LineWidth',1.5,'HandleVisibility','off','LabelHorizontalAlignment','left','LabelVerticalAlignment','bottom');

ax = gca;
ax.YAxis.Color = 'k';
ax.YAxis.FontSize = fs;
ax.XAxis.FontSize = fs;
ax.YAxis.Exponent = 0;

%ytickformat('%,6.0f')
xticks(find(WeekNumber==1))
if l == 1
    title('Projected path of ICU','FontSize',fs,'FontWeight','normal')
    xticklabels(MonthWeekEN(WeekNumber==1))
    %xticklabels(datestr(MonthWeekEN(xtick1), 'mmm-yy'))
elseif l == 2
    title('重症患者数の推移','FontSize',fs,'FontWeight','normal','FontName',fn)
    xticklabels(MonthWeekJP(WeekNumber==1))
    legend([p(2),p(4)], 'ワクチン接種50％','五輪中止','FontSize',16,'FontName',fn,'Location','southeast');
end
% lgd = legend;
%lgd.NumColumns = 2;
xtickangle(45)
xlim([Tdata-7 Tdata+33])
